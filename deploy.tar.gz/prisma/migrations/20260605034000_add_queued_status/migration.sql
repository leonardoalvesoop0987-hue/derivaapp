ALTER TYPE "SessionCardStatus" ADD VALUE 'QUEUED';
